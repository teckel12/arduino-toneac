// ---------------------------------------------------------------------------
// toneAC Library - v1.3 - 12/12/2014  modified version by Eric Kreuwels
//
// AUTHOR/LICENSE:
// Created by Tim Eckel - teckel@leethost.com
// Copyright 2014 License: GNU GPL v3 http://www.gnu.org/licenses/gpl-3.0.html
//
// LINKS:
// Project home: http://code.google.com/p/arduino-tone-ac/
// Blog: http://arduino.cc/forum/index.php/topic,142097.msg1066968.html
//
// DISCLAIMER:
// This software is furnished "as is", without technical support, and with no 
// warranty, express or implied, as to its usefulness for any purpose.
//
// PURPOSE:
// Replacement to the standard tone library with the advantage of nearly twice
// the volume, higher frequencies (even if running at a lower clock speed),
// higher quality (less clicking), nearly 1.5k smaller compiled code and less
// stress on the speaker. Disadvantages are that it must use certain pins and
// it uses two pins instead of one. But, if you're flexible with your pin
// choices, this is a great upgrade. It also uses timer 1 instead of timer 2,
// which may free up a conflict you have with the tone library. It exclusively 
// uses port registers for the fastest and smallest code possible.
//
// USAGE:
// Connection is very similar to a piezo or standard speaker. Except, instead
// of connecting one speaker wire to ground you connect both speaker wires to
// Arduino pins. The pins you connect to are specific, as toneAC lets the
// ATmega microcontroller do all the pin timing and switching. This is
// important due to the high switching speed possible with toneAC and to make
// sure the pins are alyways perfectly out of phase with each other
// (push/pull). See the below CONNECTION section for which pins to use for
// different Arduinos. Just as usual when connecting a speaker, make sure you
// add an inline 100 ohm resistor between one of the pins and the speaker wire.
//
// CONNECTION:
//   Pins  9 & 10 - ATmega328, ATmega128, ATmega640, ATmega8, Uno, Leonardo, etc.
//   Pins 11 & 12 - ATmega2560/2561, ATmega1280/1281, Mega

// alternative pinning via compile option for ATmega640, ATmega2560, ATmega1280:  
//#define USE_PINS_2_3
#define USE_PINS_6_7
//#define USE_PINS_7_8
//#define USE_PINS_11_12

//   Pins 12 & 13 - ATmega1284P, ATmega644
//   Pins 14 & 15 - Teensy 2.0
//   Pins 25 & 26 - Teensy++ 2.0

// uncomment one:

// and select a timer 
#define USE_TIMER1
//#define USE_TIMER2
//#define USE_TIMER3
//#define USE_TIMER4

//
// SYNTAX:
//   toneAC( frequency [, volume [, length [, background ]]] ) - Play a note.
//     Parameters:
//       * frequency  - Play the specified frequency indefinitely, turn off with toneAC().
//       * volume     - [optional] Set a volume level. (default: 10, range: 0 to 10 [0 = off])
//       * length     - [optional] Set the length to play in milliseconds. (default: 0 [forever], range: 0 to 2^32-1)
//       * background - [optional] Play note in background or pause till finished? (default: false, values: true/false)
//   toneAC()    - Stop playing.
//   noToneAC()  - Same as toneAC().
//
// HISTORY:
// 01/27/2013 v1.2 - Fixed a counter error which went "over the top" and caused
// periods of silence (thanks Krodal). For advanced users needing tight code,
// the TONEAC_TINY switch in toneAC.h activates a version of toneAC() that
// saves 110 bytes. With TONEAC_TINY, the syntax is toneAC(frequency, length)
// while playing the note at full volume forever in the background. Added
// support for the ATmega 640, 644, 1281, 1284P and 2561 microcontrollers.
//
// 01/16/2013 v1.1 - Option to play notes in background, returning control back
// to your sketch for processing while note plays (similar to the way the tone
// library works). Volume is now linear and in the range from 0-10. Now uses
// prescaler 256 instead of 64 for frequencies below 122 Hz so it can go down
// to 1 Hz no matter what speed the CPU is clocked at (helpful if using toneAC
// to control a two-pin dual LED).
//
// 01/11/2013 v1.0 - Initial release.
//
// ---------------------------------------------------------------------------

#ifndef toneAC_h
  #define toneAC_h

  #if defined(ARDUINO) && ARDUINO >= 100
    #include <Arduino.h>
  #else
    #include <WProgram.h>
  #endif

  //#define TONEAC_TINY // Uncomment to use alternate function toneAC(frequency, length) that saves 110 bytes.

  #if defined(__AVR_ATmega8__) || defined(__AVR_ATmega128__)
    #define TCCR2A TCCR2
    #define TCCR2B TCCR2
    #define TIMSKx TIMSK
    #define COM2A1 COM21
    #define COM2A0 COM20
    #define OCR2A  OCR2
    #define TIMERx_COMPA_vect TIMER2_COMP_vect
  #else
    #ifdef USE_TIMER1 // Activate the timer 1 interrupt
      #define TIMSKx            TIMSK1
      #define OCIExA            OCIE1A   
      #define TIMERx_COMPA_vect TIMER1_COMPA_vect
    #endif      .
    #ifdef USE_TIMER2 // Activate the timer 2 interrupt
      #define TIMSKx            TIMSK2
      #define OCIExA            OCIE2A   
      #define TIMERx_COMPA_vect TIMER2_COMPA_vect
    #endif   
    #ifdef USE_TIMER3 // Activate the timer 3 interrupt
      #define TIMSKx            TIMSK3
      #define OCIExA            OCIE3A   
      #define TIMERx_COMPA_vect TIMER3_COMPA_vect
    #endif      .
    #ifdef USE_TIMER4 // Activate the timer 4 interrupt
      #define TIMSKx            TIMSK4
      #define OCIExA            OCIE4A   
      #define TIMERx_COMPA_vect TIMER4_COMPA_vect
    #endif      .
  #endif
  
  #if defined (__AVR_ATmega32U4__) || defined(__AVR_ATmega1281__) || defined(__AVR_ATmega2561__)
    #define PWMTxAMASK DDB5
    #define PWMTxBMASK DDB6
    #define PWMTxDREG  DDRB
    #define PWMTxPORT  PORTB
    #define TCCRxA     TCCR1A
    #define TCCRxB     TCCR1B
    #define ICRx       ICR1
    #define TCNTx      TCNT1
    #define OCRxA      OCR1A 
    #define OCRxB      OCR1B
    #define COMxA1     COM1A1
    #define COMxB1     COM1B1
    #define COMxB0     COM1B0
   #elif defined (__AVR_ATmega640__) || defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__) // support for ALTERNATIVE_PINS
    #ifdef USE_PINS_6_7
      #define PWMTxAMASK DDH3
      #define PWMTxBMASK DDH4
      #define PWMTxDREG  DDRH
      #define PWMTxPORT  PORTH
      #define TCCRxA     TCCR4A
      #define TCCRxB     TCCR4B
      #define ICRx       ICR4
      #define TCNTx      TCNT4
      #define OCRxA      OCR4A 
      #define OCRxB      OCR4B
      #define COMxA1     COM4A1
      #define COMxB1     COM4B1
      #define COMxB0     COM4B0
    #elif defined USE_PINS_7_8
      #define PWMTxAMASK DDH4
      #define PWMTxBMASK DDH5
      #define PWMTxDREG  DDRH
      #define PWMTxPORT  PORTH
      #define TCCRxA     TCCR4A
      #define TCCRxB     TCCR4B
      #define ICRx       ICR4
      #define TCNTx      TCNT4
      #define OCRxA      OCR4B 
      #define OCRxB      OCR4C
      #define COMxA1     COM4A1
      #define COMxB1     COM4B1
      #define COMxB0     COM4B0
    #elif defined USE_PINS_2_3
      #define PWMTxAMASK DDE4
      #define PWMTxBMASK DDE5
      #define PWMTxDREG  DDRE
      #define PWMTxPORT  PORTE
      #define TCCRxA     TCCR3A
      #define TCCRxB     TCCR3B
      #define ICRx       ICR3
      #define TCNTx      TCNT3
      #define OCRxA      OCR3A 
      #define OCRxB      OCR3B
      #define COMxA1     COM3A1
      #define COMxB1     COM3B1
      #define COMxB0     COM3B0
    #else //  USE_PINS_11_12
      #define PWMTxAMASK DDB5
      #define PWMTxBMASK DDB6
      #define PWMTxDREG  DDRB
      #define PWMTxPORT  PORTB
      #define TCCRxA     TCCR1A
      #define TCCRxB     TCCR1B
      #define ICRx       ICR1
      #define TCNTx      TCNT1
      #define OCRxA      OCR1A 
      #define OCRxB      OCR1B
      #define COMxA1     COM1A1
      #define COMxB1     COM1B1
      #define COMxB0     COM1B0
    #endif
  #elif defined(__AVR_ATmega1284P__) || defined(__AVR_ATmega644__) || defined(__AVR_ATmega644P__)
    #define PWMTxAMASK DDD4
    #define PWMTxBMASK DDD5
    #define PWMTxDREG  DDRD
    #define PWMTxPORT  PORTD
    #define TCCRxA     TCCR1A
    #define TCCRxB     TCCR1B
    #define ICRx       ICR1
    #define TCNTx      TCNT1
    #define OCRxA      OCR1A 
    #define OCRxB      OCR1B
    #define COMxA1     COM1A1
    #define COMxB1     COM1B1
    #define COMxB0     COM1B0
  #else
    #define PWMTxAMASK DDB1
    #define PWMTxBMASK DDB2
    #define PWMTxDREG  DDRB
    #define PWMTxPORT  PORTB
    #define TCCRxA     TCCR1A
    #define TCCRxB     TCCR1B
    #define ICRx       ICR1
    #define TCNTx      TCNT1
    #define OCRxA      OCR1A 
    #define OCRxB      OCR1B
    #define COMxA1     COM1A1
    #define COMxB1     COM1B1
    #define COMxB0     COM1B0
  #endif

  #ifndef TONEAC_TINY
    void toneAC(unsigned long frequency = 0, uint8_t volume = 10, unsigned long length = 0, uint8_t background = false);
  #else
    void toneAC(unsigned long frequency = 0, unsigned long length = 0);
  #endif
  void noToneAC();
  boolean toneDone();
#endif
